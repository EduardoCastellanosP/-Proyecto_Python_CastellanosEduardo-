import os 
import modules.utils.menus as mn
import modules.utils.ScreenController as sc

def menuprincipal():
    sc.borrar_pantalla
    print(menuprincipal)
