import json
import modules.utils.menus as mn
import modules.utils.opciones as op
from modules.utils.validaciones import sololetras as sl, solonumeros as sn
DB_FILE = "data/dbtiendalibros.json"

def editar():
    while True:
        print("Mostrando menú:")
        print(mn.menueditar)
        opcion = op.opciones()
        print(f"Opción seleccionada: {opcion}")

        match opcion:
            case 1:
                try:
                    # Cargar el archivo JSON
                    with open(DB_FILE, "r", encoding="utf-8") as file:
                        data = json.load(file)
                except (json.JSONDecodeError, FileNotFoundError):
                    print("Error: El archivo JSON está corrupto o no existe.")
                    return

                # Menú de categorías
                print("\nSeleccione una categoría para editar:")
                print("1. Libros")
                print("2. Música")
                print("3. Películas")

            
                categoria_opcion = sn("\nIngrese el número de la categoría: ")
                

                # Determinar la categoría seleccionada
                match categoria_opcion:
                    case 1:
                        categoria = "libros"
                    case 2:
                        categoria = "Musica"
                    case 3:
                        categoria = "peliculas"
                    case _:
                        print("Opción no válida.")
                        return

                # Verificar si la categoría existe en el JSON
                if categoria not in data or not isinstance(data[categoria], list):
                    print(f"Error: No se encontró la categoría '{categoria}'.")
                    return

                # Mostrar los títulos disponibles
                print(f"\n{categoria} disponibles:")
                for idx, item in enumerate(data[categoria]):
                    print(f"{idx + 1}. {item.get('Titulo', 'Sin título')}")

                # Pedir al usuario que elija un título para editar
                
                seleccion = sn("\nIngrese el número del título que desea editar: ") - 1
                if seleccion < 0 or seleccion >= len(data[categoria]):
                    print("Selección fuera de rango.")
                    return
            

                # Mostrar el título actual y pedir el nuevo título
                titulo_actual = data[categoria][seleccion]["Titulo"]
                nuevo_titulo = input(f"Ingrese el nuevo título para '{titulo_actual}': ").strip()

                if nuevo_titulo:
                    data[categoria][seleccion]["Titulo"] = nuevo_titulo

                    # Guardar los cambios en el JSON
                    with open(DB_FILE, "w", encoding="utf-8") as file:
                        json.dump(data, file, indent=4, ensure_ascii=False)

                    print(f"\n Título actualizado con éxito en '{categoria}': '{titulo_actual}' a '{nuevo_titulo}'")
                else:
                    print("No se ingresó un título válido.")

            case 2:
                try:
                    # Cargar el archivo JSON
                    with open(DB_FILE, "r", encoding="utf-8") as file:
                        data = json.load(file)
                except (json.JSONDecodeError, FileNotFoundError):
                    print("Error: El archivo JSON está corrupto o no existe.")
                    return

                # Menú de categorías
                print("\nSeleccione una categoría para editar:")
                print("1. Libros (Autor)")
                print("2. Música (Artista)")
                print("3. Películas (Director)")

            
                categoria_opcion = sn("\nIngrese el número de la categoría: ")
                

                # Determinar la categoría y clave
                match categoria_opcion:
                    case 1:
                        categoria, clave = "libros", "Autor"
                    case 2:
                        categoria, clave = "Musica", "Artista"
                    case 3:
                        categoria, clave = "peliculas", "Director"
                    case _:
                        print("Opción no válida.")
                        return

                # Verificar si la categoría existe en el JSON
                if categoria not in data or not isinstance(data[categoria], list):
                    print(f"Error: No se encontró la categoría '{categoria}'.")
                    return

                # Mostrar los títulos disponibles con su autor/director/artista actual
                print(f"\n{categoria} disponibles:")
                for idx, item in enumerate(data[categoria]):
                    print(f"{idx + 1}. {item.get('Titulo', 'Sin título')} - {clave}: {item.get(clave, 'Desconocido')}")

                # Pedir al usuario que elija un título para editar
            
                seleccion = sn("\nIngrese el número del título que desea editar: ") - 1
                if seleccion < 0 or seleccion >= len(data[categoria]):
                    print("Selección fuera de rango.")
                    return
                

                # Mostrar el nombre actual y pedir el nuevo
                nombre_actual = data[categoria][seleccion].get(clave, "No especificado")
                nuevo_nombre = input(f"Ingrese el nuevo {clave} para '{data[categoria][seleccion]['Titulo']}' (actual: {nombre_actual}): ").strip()

                if nuevo_nombre:
                    data[categoria][seleccion][clave] = nuevo_nombre

                    # Guardar los cambios en el JSON
                    with open(DB_FILE, "w", encoding="utf-8") as file:
                        json.dump(data, file, indent=4, ensure_ascii=False)

                    print(f"\n {clave} actualizado con éxito en '{categoria}': '{nombre_actual}' a '{nuevo_nombre}'")
                else:
                    print("No se ingresó un valor válido.")

            case 3:
                try:
                    with open(DB_FILE, "r", encoding="utf-8") as file:
                        data = json.load(file)
                except (json.JSONDecodeError, FileNotFoundError):
                    print("Error: El archivo JSON está corrupto o no existe.")
                    return

                print("\nSeleccione una categoría para editar:")
                print("1. Libros (Genero)")
                print("2. Música (Genero)")
                print("3. Películas (Genero)")

                categoria_opcion = sn("\nIngrese el número de la categoría: ")
            

                match categoria_opcion:
                    case 1:
                        categoria, clave = "libros", "Genero"
                    case 2:
                        categoria, clave = "Musica", "Genero"
                    case 3:
                        categoria, clave = "peliculas", "Genero"
                    case _:
                        print("Opción no válida.")
                        return

                if categoria not in data or not isinstance(data[categoria], list):
                    print(f"error: No se encontró la categoría '{categoria}'.")
                    return

                print(f"\n{categoria} disponibles:")
                for idx, item in enumerate(data[categoria]):
                    print(f"{idx + 1}. {item.get('Titulo', 'Sin título')} - Genero: {item.get(clave, 'Desconocido')}")

            
                    seleccion = sn("\nIngrese el número del título que desea editar: ") - 1
                    if seleccion < 0 or seleccion >= len(data[categoria]):
                        print("Selección fuera de rango.")
                        return
            

                genero_actual = data[categoria][seleccion].get(clave, "No especificado")
                nuevo_genero = input(f"Ingrese el nuevo Género para '{data[categoria][seleccion]['Titulo']}' (actual: {genero_actual}): ").strip()

                if nuevo_genero:
                    data[categoria][seleccion][clave] = nuevo_genero

                    with open(DB_FILE, "w", encoding="utf-8") as file:
                        json.dump(data, file, indent=4, ensure_ascii=False)

                    print(f"\n Género actualizado con éxito en '{categoria}': '{genero_actual}' a '{nuevo_genero}'")
                else:
                    print("No se ingresó un valor válido.")
        
            case 4:
                try:
                    with open(DB_FILE, "r", encoding="utf-8") as file:
                        data = json.load(file)
                except (json.JSONDecodeError, FileNotFoundError):
                    print("Error: El archivo JSON está corrupto o no existe.")
                    return

                print("\nSeleccione una categoría para editar:")
                print("1. Libros (Valoración)")
                print("2. Música (Valoración)")
                print("3. Películas (Valoración)")

                
                categoria_opcion = sn("\nIngrese el número de la categoría: ")
            

                match categoria_opcion:
                    case 1:
                        categoria, clave = "libros", "Valoracion"
                    case 2:
                        categoria, clave = "Musica", "Valoracion"
                    case 3:
                        categoria, clave = "peliculas", "Valoracion"
                    case _:
                        print("Opción no válida.")
                        return

                if categoria not in data or not isinstance(data[categoria], list):
                    print(f"Error: No se encontró la categoría '{categoria}'.")
                    return

                print(f"\n{categoria} disponibles:")
                for idx, item in enumerate(data[categoria]):
                    print(f"{idx + 1}. {item.get('Titulo', 'Sin título')} - Valoración: {item.get(clave, 'No calificado')}")

                
                seleccion = sn("\nIngrese el número del título que desea editar: ") - 1
                if seleccion < 0 or seleccion >= len(data[categoria]):
                    print("Selección fuera de rango.")
                    return
                

                valoracion_actual = data[categoria][seleccion].get(clave, "No calificado")
                try:
                    nueva_valoracion = float(input(f"Ingrese la nueva valoración para '{data[categoria][seleccion]['Titulo']}' (actual: {valoracion_actual}, 0-5): ").strip())

                    if nueva_valoracion < 0 or nueva_valoracion > 5:
                        print("La valoración debe estar entre 0 y 5.")
                        return

                except ValueError:
                    print("Entrada no válida. Ingrese un número entre 0 y 5.")
                    return

                data[categoria][seleccion][clave] = nueva_valoracion

                with open(DB_FILE, "w", encoding="utf-8") as file:
                    json.dump(data, file, indent=4, ensure_ascii=False)

                print(f"\n Valoración actualizada con éxito en '{categoria}': '{valoracion_actual}' a '{nueva_valoracion}'")

            case 5:
                return
                
                


