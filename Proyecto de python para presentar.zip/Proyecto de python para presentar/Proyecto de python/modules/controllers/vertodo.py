import modules.utils as mu
import modules.utils.ScreenController as sc
import modules.utils.corefiles as mc
import modules.utils.menus as mn
import modules.utils.opciones as op
import modules.utils.corefiles as cr
import json

DB_FILE = "data/dbtiendalibros.json"

def pausar_pantalla():
    input("Presione una tecla para continuar . . .")  


def listar_elementos_por_titulo(titulo):
    data = cr.read_json(DB_FILE)

    if titulo == "libros":
        elementos = [libro["Titulo"] for libro in data.get("libros", [])]
    elif titulo == "peliculas":
        elementos = [pelicula["Titulo"] for pelicula in data.get("peliculas", [])]
    elif titulo == "Musica":
        elementos = [musica["Titulo"] for musica in data.get("Musica", [])]
    else:
        print(f"Categoría '{titulo}' no reconocida.")
        return

    if not elementos:
        print(f"No hay elementos registrados en la categoría '{titulo}'.")
        return


    print(f"\nLista de {titulo}:")
    for idx, item in enumerate(elementos, start=1):
        print(f"{idx}. {item}")  

    print("\n")



def listar_elementos_por_genero(genero):
    
    data = cr.read_json(DB_FILE)
    
    
    todos_los_elementos = []
    todos_los_elementos.extend(data.get('libros', []))
    todos_los_elementos.extend(data.get('peliculas', []))
    todos_los_elementos.extend(data.get('Musica', []))
    
    
    elementos_filtrados = [item for item in todos_los_elementos if item.get('genero') == genero]
    
    
    if not elementos_filtrados:
        print(f"No se encontraron elementos con el género '{genero}'.")
        return
    
    
    print(f"\nLista de elementos con el género '{genero}':")
    for idx, item in enumerate(elementos_filtrados, start=1):
        print(f"{idx}. {item['Titulo']} - {item['genero']}") 
    print("\n")


def VerTodo():
    
    menuvertodo = """
    Opción 1: Ver Libros
    Opción 2: Ver Películas
    Opción 3: Ver Música
    """
    print(menuvertodo)
    
    opcion = op.opciones()

    match opcion:
        case 1:
            listar_elementos_por_titulo('libros')  
            
        case 2:
            listar_elementos_por_titulo('peliculas') 
           
        case 3:
            listar_elementos_por_titulo('Musica')  
              
if __name__ == "__main__":
    VerTodo()