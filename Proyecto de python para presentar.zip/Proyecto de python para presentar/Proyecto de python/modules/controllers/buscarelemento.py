            
import modules.utils.menus as mn
import modules.utils.opciones as op
import modules.utils.corefiles as cf
import modules.controllers.anadir as an
import json
import modules.utils.ScreenController as sc
from modules.utils.validaciones import sololetras as sl, solonumeros as sn
DB_FILE = "data/dbtiendalibros.json"

def buscarelement():
    while True:
        print(mn.menubuscar)
        opcion = op.opciones()

        match opcion:
            case 1:
                # Leer la base de datos
                print("\nSeleccione la categoría para buscar:")
                print("1. Libros")
                print("2. Música")
                print("3. Películas")

                
                opcion = sn("\nIngrese el número de la categoría: ")
                

                match opcion:
                    case 1:
                        categoria = "libros"
                    case 2:
                        categoria = "Musica"
                    case 3:
                        categoria = "peliculas"
                    case _:
                        print("Opción no válida.")
                        return

                # Cargar los datos desde el JSON
                biblioteca = cf.read_json(DB_FILE)

                # Obtener la lista de la categoría seleccionada
                elementos = biblioteca.get(categoria, [])

                if not elementos:
                    print(f"No hay registros en la categoría '{categoria}'.")
                    return

                # Solicitar el título a buscar
                titulo_buscar = input(f"Ingrese el título en '{categoria}' que desea buscar: ").strip()

                # Filtrar por título
                elementos_filtrados = [
                    item for item in elementos 
                    if titulo_buscar.lower() in item.get('Titulo', '').lower()
                ]

                # Mostrar resultados
                if elementos_filtrados:
                    print(f"\nResultados encontrados en '{categoria}':")
                    for item in elementos_filtrados:
                        autor_director_artista = item.get("Autor", item.get("Director", item.get("Artista", "Desconocido")))
                        print(f"Título: {item['Titulo']}, Interprete: {autor_director_artista}")
                        sc.pausar_pantalla()
                else:
                    print("No se encontraron resultados con ese título.")



            case 2:
                    # Leer la base de datos
                print("\nSeleccione la categoría para buscar:")
                print("1. Libros (Autor)")
                print("2. Música (Artista)")
                print("3. Películas (Director)")

            
                opcion = sn("\nIngrese el número de la categoría: ")
                
                match opcion:
                    case 1:
                        categoria = "libros"
                        clave_busqueda = "Autor"
                    case 2:
                        categoria = "Musica"
                        clave_busqueda = "Interprete"
                    case 3:
                        categoria = "peliculas"
                        clave_busqueda = "Director"
                    case _:
                        print("Opción no válida.")
                        return

            # Cargar los datos desde el JSON
                biblioteca = cf.read_json(DB_FILE)

                # Obtener la lista de la categoría seleccionada
                elementos = biblioteca.get(categoria, [])

                if not elementos:
                    print(f"No hay registros en la categoría '{categoria}'.")
                    return

                # Solicitar el nombre a buscar
                nombre_buscar = input(f"Ingrese el {clave_busqueda.lower()} en '{categoria}' que desea buscar: ").strip()

                # Filtrar por Autor/Director/Artista
                elementos_filtrados = [
                    item for item in elementos #Itera sobre cada item dentro de elementos.
                    if nombre_buscar.lower() in item.get(clave_busqueda, '').lower()
                ]

                # Mostrar resultados
                if elementos_filtrados:
                    print(f"\nResultados encontrados en '{categoria}':")
                    for item in elementos_filtrados:
                        print(f"{clave_busqueda}: {item[clave_busqueda]}, Título: {item.get('Titulo', 'Desconocido')}")
                        sc.pausar_pantalla()
                else:
                    print(f"No se encontraron resultados con ese {clave_busqueda.lower()}.")

                
            case 3:
                
                print("\nSeleccione la categoría para buscar:")
                print("1. Libros")
                print("2. Música")
                print("3. Películas")

            
                opcion = sn("\nIngrese el número de la categoría: ")
                match opcion:
                    case 1:
                        categoria = "libros"
                    case 2:
                        categoria = "Musica"
                    case 3:
                        categoria = "peliculas"
                    case _:
                        print("Opción no válida.")
                        return

                # Cargar los datos desde el JSON
                biblioteca = cf.read_json(DB_FILE)

                # Obtener la lista de la categoría seleccionada
                elementos = biblioteca.get(categoria, [])

                if not elementos:
                    print(f"No hay registros en la categoría '{categoria}'.")
                    return

                # Solicitar el género a buscar
                genero_buscar = input(f"Ingrese el género en '{categoria}' que desea buscar: ").strip()

                # Filtrar por género
                elementos_filtrados = [
                    item for item in elementos #Itera sobre cada item dentro de elementos.
                    if genero_buscar.lower() in item.get('Genero', '').lower()
                ]

                # Mostrar resultados
                if elementos_filtrados:
                    print(f"\nResultados encontrados en '{categoria}':")
                    for item in elementos_filtrados:
                        print(f"Género: {item['Genero']}, Título: {item.get('Titulo', 'Desconocido')}")
                        sc.pausar_pantalla()
                else:
                    print("No se encontraron resultados con ese género.")
            case 4:
                return