import json
import os
from typing import Dict, List, Optional

def read_json(file_path):
    """Lee un archivo JSON y maneja errores si el archivo está vacío o malformado."""
    if not os.path.exists(file_path):  # Si el archivo no existe, retorna un diccionario vacío
        return {}

    try:
        with open(file_path, "r", encoding="utf-8") as file:
            content = file.read().strip()  # Leer el contenido y eliminar espacios en blanco
            if not content:  # Si el archivo está vacío, retorna un diccionario vacío
                return {}

            return json.loads(content)  # Cargar los datos JSON
    except (json.JSONDecodeError, FileNotFoundError):
        return {}  # Si hay un error, retorna un diccionario vacío


def write_json(file_path: str, data: Dict) -> None:
    """Escribe un diccionario en un archivo JSON, creando la carpeta si no existe."""
    os.makedirs(os.path.dirname(file_path), exist_ok=True)  # Crea la carpeta si no existe

    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def update_json(file_path, data, keys):
    """Actualiza un archivo JSON añadiendo nuevos datos en la clave indicada."""
    current_data = read_json(file_path)  # Cargar el JSON actual
    if current_data is None:  # Asegurar que es un diccionario
        current_data = {}

    last_key = keys[-1]

    if last_key not in current_data:
        current_data[last_key] = []  # Inicializa la clave como una lista

    current_data[last_key].append(data)  # Agrega los datos a la lista

    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(current_data, file, indent=4, ensure_ascii=False) 


def delete_json(file_path: str, path: List[str]) -> bool:
    """
    Elimina datos en la ruta especificada
    Retorna True si se eliminó exitosamente
    """
    data = read_json(file_path)
    current = data

    for key in path[:-1]:
        if key not in current:
            return False
        current = current[key]

    if path and path[-1] in current:
        del current[path[-1]]
        write_json(file_path, data)
        return True
    return False

def initialize_json(file_path: str, initial_structure: Dict) -> None:
    """
    Inicializa el archivo con una estructura base si no existe
    """
    if not os.path.isfile(file_path):
        write_json(file_path, initial_structure)
    else:
        current_data = read_json(file_path)
        for key, value in initial_structure.items():
            if key not in current_data:
                current_data[key] = value
        write_json(file_path, current_data)

# corefiles.py (al final del archivo)
