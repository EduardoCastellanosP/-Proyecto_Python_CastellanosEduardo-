import json
import modules.utils.corefiles as cf

DB_FILE = "data/dbtiendalibros.json"

def vertodosloselementos():
    # Cargar los datos desde el JSON
    biblioteca = cf.read_json(DB_FILE)

    if not biblioteca:
        print("No hay datos en la base de datos.")
        return

    # Iterar sobre las categorías y mostrar los elementos
    for categoria, elementos in biblioteca.items():
        if isinstance(elementos, list) and elementos:
            print(f"\n {categoria}:")
            for item in elementos:
                titulo = item.get("Titulo", "Sin título")
                creador = item.get("Autor") or item.get("Director") or item.get("Artista") or "Desconocido"
                genero = item.get("Genero", "Sin género")
                valoracion = item.get("Valoracion", "Sin valoración")
                print(f"- {titulo} |  {creador} |  {genero} |  {valoracion}")
        else:
            print(f"\n {categoria}: No hay elementos registrados.")

