import modules.utils.menus as mn
import modules.utils.opciones as op
import modules.utils.corefiles as cf
import json
from modules.utils.validaciones import sololetras as sl, solonumeros as sn, numerosyletras as nl
import modules.utils.ScreenController as sc
DB_FILE = "data/dbtiendalibros.json"

def eliminar():
    while True:
        print(mn.menueliminar)
        opcion = op.opciones()
        
        match opcion:
            case 1:
                while True:
                    # Cargar el JSON correctamente
                    with open(DB_FILE, "r", encoding="utf-8") as file:
                        data = json.load(file)

                    for categoria, elementos in data.items():
                        print(f"{categoria}:")
                        for elemento in elementos:
                            print(elemento['Titulo'])

                    # Solicitar el título a eliminar
                    select = input("Ingrese el título a eliminar: ").lower()

                    eliminado = False
                    for categoria, elementos in data.items():
                        for elemento in elementos:
                            if elemento['Titulo'].lower() == select:
                                elementos.remove(elemento)
                                eliminado = True
                                break  # Salir del bucle interno después de eliminar
                        if eliminado:
                            break  # Salir del bucle externo si ya se eliminó

                    if eliminado:
                        # Guardar los cambios en el archivo
                        with open(DB_FILE, "w", encoding="utf-8") as file:
                            json.dump(data, file, indent=4, ensure_ascii=False)
                        print("Se eliminó correctamente.")
                    else:
                        print("Título no encontrado.")
                        
                    addotros=sl("Desea eliminar otro? S/N: ").upper()
                    sc.borrar_pantalla()
                    if addotros != 'S':
                        print("Regresando al menú principal")
                        break    
                    
            case 2:
                while True:
                    data=cf.read_json(DB_FILE)

                    for categoria, elementos in data.items():
                        print(f"{categoria}:")
                        for elemento in elementos:
                            print( "Titulo: ", elemento['Titulo'],"Id: ",elemento['id'])

                    select=nl("Ingrese el identicador")
                    for categoria, elementos in data.items():
                        for elemento in elementos:
                            if elemento["id"].lower()==select:
                                elementos.remove(elemento)
                                break
                        
                    # Guardar los cambios en el archivo
                    with open(DB_FILE, "w", encoding="utf-8") as file:
                        json.dump(data, file, indent=4, ensure_ascii=False)
                    print("Se eliminó correctamente.")
                    
                    addotros2=sl("Desea eliminar otro? S/N: ").upper()
                    sc.borrar_pantalla()
                    if addotros2!= "S":
                        print("Regresando al menú principal")
                        break
                    
            case 3:
                print("Regresando al menú principal")
                return