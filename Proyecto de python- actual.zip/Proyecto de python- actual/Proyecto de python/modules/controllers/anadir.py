import modules.utils.menus as mn
import modules.utils.ScreenController as sc
from modules.utils.validaciones import sololetras as sl, solonumeros as sn, numerosyletras as nl
import modules.utils.opciones as op
import modules.utils.corefiles as cf
import json
DB_FILE = "data/dbtiendalibros.json"

def anadir():
    print(mn.menuañadir)
    opcion=op.opciones()

    match opcion:
        case 1:
            while True:
                id=nl("Ingrese el id del libro: ")
                nombre_libro=input("Ingrese el nombre del libro: ")
                autor=input("Ingrese el autor del libro: ")
                genero=input('Ingrese el genero: ')
                valoracion=sl("Ingrese la valoracion del libro: ")
                biblioteca= {                       # Creación de un diccionario llamado "biblioteca" que almacena información sobre un libro
                    "id":id,                        # Identificador único del libro (puede ser un número o string)
                    "Titulo":nombre_libro,          # Nombre o título del libro
                    "Autor": autor,
                    "Genero":genero,
                    "Valoracion":valoracion                  # Valoración inicial del libro
            }
                sc.borrar_pantalla()
                addlibro=sl("¿Quiere añadir otro libro? S/N:").upper()
                sc.borrar_pantalla()
                if addlibro != 'S':
                    break
                sc.borrar_pantalla
            cf.update_json(DB_FILE, biblioteca, ["libros"])# Actualiza un archivo JSON con nuevos datos
            print("Libro agregado correctamente.")

        case 2:
            while True:
                id=nl("Ingrese el identificador: ")
                nombre_pelicula=input('Ingrese el nombre de la pelicula: ')
                genero=input('Ingrese el genero: ')
                director=input('Ingrese el nombre del director: ')
                valoracion=sl("Ingrese la valoracion de la pelicula: ")
                movies= {
                     "id":id,
                    "Titulo":nombre_pelicula,
                    "Genero":genero,
                    'Director':director,
                    "Valoracion":valoracion
                }
                sc.borrar_pantalla
                addpelicula=sl("¿Quiere añadir otra pelicula? S/N: ").upper()
                sc.borrar_pantalla()
                if addpelicula != 'S':
                    break
            cf.update_json(DB_FILE,movies,['peliculas']) # Actualiza un archivo JSON con nuevos datos

        case 3:
            while True:
                id=nl("Ingrese el identificador la cancion: ")
                Nombre_cancion=input("Ingrese el nombre de la cancion: ")
                cantante=input("Ingrese el nombre del cantante: ")
                Genero=input('Ingrese el genero: ')
                valoracion=sl("Ingrese la valoracion de la cancion: ")
                musica={
                    "id":id,
                    "Titulo":Nombre_cancion,
                    "Artista":cantante,
                    "Genero":Genero,
                    "Valoracion":valoracion
                }
                sc.borrar_pantalla()
                addcancion=sl("¿Quiere añadir otra cancion? S/N: ").upper()
                sc.borrar_pantalla()
                if addcancion != 'S':
                    break
            cf.update_json(DB_FILE,musica,['Musica'])# Actualiza un archivo JSON con nuevos datos

        case 4:
            print("Regresando al menu principal...")
            return
           

