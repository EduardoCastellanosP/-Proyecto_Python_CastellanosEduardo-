
import modules.utils.ScreenController as sc
import modules.utils.menus as ui
import modules.controllers.anadir as an
import modules.controllers.vertodo as vt
import modules.utils.corefiles as cf
import json
import modules.utils.validaciones as vd
import modules.utils.opciones as op
import modules.controllers.buscarelemento as bs
import modules.controllers.delete as dl
import modules.controllers.editar as ed
import modules.controllers.vertodosloselementos as ve
DB_FILE="data/dbtiendalibros.json"
def menu():
    while True:
        sc.borrar_pantalla()
        print(ui.menuprincipal)
        try:
            option=op.opciones()
        except ValueError:    
            print('Apreciado Usuario, Usted se encuentra ingresando un caracter erroneo')
            sc.pausar_pantalla()
            return menu()
        else: 
            
            match option:
                case 1:
                    sc.borrar_pantalla()
                    an.anadir()
                    sc.pausar_pantalla()
                    return menu()
                case 2:
                    sc.borrar_pantalla()
                    ve.vertodosloselementos()
                    sc.pausar_pantalla()
                    return menu()
                case 3:
                    sc.borrar_pantalla()
                    bs.buscarelement()
                    sc.pausar_pantalla()
                    return menu()
                case 4:
                    sc.borrar_pantalla()
                    ed.editar()
                    sc.pausar_pantalla()
                    return menu()
                case 5:
                    sc.borrar_pantalla()
                    dl.eliminar()
                    sc.pausar_pantalla
                
                case 6:
                    sc.borrar_pantalla()
                    vt.VerTodo()
                    sc.pausar_pantalla()
                    return menu()
                
                case 7:
                    print('Guardada y Cargada la Colección')
                    sc.pausar_pantalla()
                case 8:
                    print('Saliendo del programa')
                    break
                case _:
                    print('Opcion Invalida')
                
    
if __name__== "__main__":
    menu()




